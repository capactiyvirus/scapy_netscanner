The pythonscript should be able to run as is. 

There are not argument parameters since we are using it to scan multiple ip's so just run it example: python scapyshodanProject.py

and wait for it to spit out the data in a csv. I added the one i made with the data i calculated which i used in the pdf.

If for some reason something doesnt work it might be a weird anomaly that did not occur of any the ip's that i have tested which where ALOT so just message me cuz it can be somthing dumb.

Otherwise i proveded the data at the bottom of the pdf or csv where I calculated general data vs all the ip's and % based on the ones active.